# COMP2300 Assignment 1

<https://cs.anu.edu.au/courses/comp2300/deliverables/01-synth/>
